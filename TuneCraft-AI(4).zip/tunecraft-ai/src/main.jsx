import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Activity, AudioLines, AudioWaveform, ArrowDownUp, ArrowLeft, ArrowRight, Check,
  ChevronDown, CircleHelp, Clock3, Disc3, Download, FileAudio, FileMusic, Headphones,
  Home, Info, LoaderCircle, Music2, Pause, Play, Plus, RefreshCw, ScanSearch, Settings2,
  Sparkles, Upload, WandSparkles, Waves, X, Zap
} from 'lucide-react';
import './styles.css';

const instruments = [
  { id:'piano', name:'Grand piano', sub:'Warm · expressive', icon:'♬', color:'#b7a4ff', desc:'Adds harmonic depth and a clear melodic voice.' },
  { id:'guitar', name:'Acoustic guitar', sub:'Organic · intimate', icon:'♩', color:'#f2b987', desc:'Adds a rhythmic pulse and a natural, intimate texture.' },
  { id:'violin', name:'Violin', sub:'Cinematic · lyrical', icon:'𝄞', color:'#ff9fba', desc:'Highlights long melodic phrases with a singing tone.' },
  { id:'flute', name:'Flute', sub:'Airy · delicate', icon:'♫', color:'#8fe0d0', desc:'Creates a light, breathy lead that leaves space around the melody.' },
  { id:'saxophone', name:'Saxophone', sub:'Soulful · rich', icon:'♬', color:'#e7ca7a', desc:'Adds a rounded, expressive lead with a jazz-inspired character.' },
  { id:'sitar', name:'Sitar', sub:'Resonant · intricate', icon:'ॐ', color:'#ffb875', desc:'Introduces resonant plucks and a distinctive Indian classical colour.' },
  { id:'drums', name:'Drums', sub:'Driving · percussive', icon:'◉', color:'#91b7ff', desc:'Strengthens the groove with a clear rhythmic foundation.' }
];
const navItems = [
  { id:'home', label:'Overview', icon:Home },
  { id:'upload', label:'Upload & analyze', icon:Upload },
  { id:'instrument', label:'Instrument lab', icon:Music2 },
  { id:'compare', label:'Compare versions', icon:ArrowDownUp },
  { id:'review', label:'AI review', icon:Sparkles }
];

function App() {
  const [page, setPage] = useState('home');
  const [file, setFile] = useState(null);
  const [audioUrl, setAudioUrl] = useState('');
  const [instrument, setInstrument] = useState('piano');
  const [generatedInstrument, setGeneratedInstrument] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [generatedUrl, setGeneratedUrl] = useState('');
  const [notice, setNotice] = useState('');
  const [demoMode, setDemoMode] = useState(true);
  const [playing, setPlaying] = useState('');
  const [progress, setProgress] = useState(0);
  const fileRef = useRef(null);
  const audioRef = useRef(null);
  const selected = instruments.find(i => i.id === instrument) || instruments[0];
  const done = !!analysis;
  const hasGenerated = !!generatedInstrument;
  const fileSize = file ? (file.size / 1024 / 1024).toFixed(2) + ' MB' : 'MP3 or WAV · up to 25 MB';

  useEffect(() => () => { if (audioUrl) URL.revokeObjectURL(audioUrl); }, [audioUrl]);
  useEffect(() => {
    if (!notice) return;
    const id = setTimeout(() => setNotice(''), 4200);
    return () => clearTimeout(id);
  }, [notice]);

  const loadFile = f => {
    if (!f) return;
    if (!/\.(mp3|wav)$/i.test(f.name) && !['audio/mpeg','audio/wav','audio/x-wav'].includes(f.type)) {
      setNotice('Please choose an MP3 or WAV audio file.'); return;
    }
    if (f.size > 25 * 1024 * 1024) { setNotice('This demo accepts files up to 25 MB.'); return; }
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setFile(f); setAudioUrl(URL.createObjectURL(f)); setAnalysis(null);
    setGeneratedUrl(''); setGeneratedInstrument(''); setProgress(0);
    setNotice('Audio loaded locally. Ready to analyze.');
  };

  const analyze = async () => {
    if (!file) { setNotice('Upload your tune first to begin analysis.'); setPage('upload'); return; }
    setIsAnalyzing(true); setProgress(0);
    for (let n = 1; n <= 4; n++) {
      await new Promise(r => setTimeout(r, 450));
      setProgress(n * 25);
    }
    // Clearly labelled illustrative analysis; no audio-analysis service is connected.
    setAnalysis({ tempo: '96 BPM', key: 'A minor', mood: 'Reflective', rhythm: 'Steady 4/4', melody: 'Moderate melodic movement' });
    setIsAnalyzing(false); setNotice('Demo analysis ready. Values are illustrative, not extracted from your audio.');
    setPage('instrument');
  };

  const generate = async () => {
    if (!file) { setNotice('Upload an audio file before choosing an instrument.'); setPage('upload'); return; }
    if (!analysis) { setNotice('Analyze your tune first.'); setPage('upload'); return; }
    setIsGenerating(true); setProgress(0);
    for (let n = 1; n <= 5; n++) {
      await new Promise(r => setTimeout(r, 380));
      setProgress(n * 20);
    }
    setGeneratedInstrument(instrument);
    setGeneratedUrl(''); // No fake generated audio: a real generation endpoint must provide this URL.
    setIsGenerating(false);
    setNotice('Demo review created. No new audio was generated because no music-generation API is connected.');
    setPage('compare');
  };

  const reset = () => {
    setFile(null); if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioUrl(''); setAnalysis(null); setGeneratedInstrument(''); setGeneratedUrl('');
    setPage('upload'); setProgress(0);
  };

  return <div className="app-shell">
    <aside className="sidebar">
      <button className="brand" onClick={() => setPage('home')} aria-label="TuneCraft AI home">
        <span className="brand-mark"><AudioWaveform size={22}/></span>
        <span><strong>TuneCraft</strong><small>AI MUSIC CO-PILOT</small></span>
      </button>
      <div className="workspace-label">WORKSPACE</div>
      <nav className="side-nav">
        {navItems.map(item => {
          const Icon = item.icon;
          return <button key={item.id} className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => setPage(item.id)}>
            <Icon size={17}/><span>{item.label}</span>{item.id === 'review' && hasGenerated && <span className="nav-dot"/>}
          </button>;
        })}
      </nav>
      <div className="sidebar-bottom">
        <div className="mini-card">
          <div className="mini-icon"><Sparkles size={16}/></div>
          <div><strong>Your creative space</strong><p>Shape your sound, one layer at a time.</p></div>
        </div>
        <div className="profile">
          <div className="avatar">TC</div><div className="profile-info"><strong>Studio session</strong><span>Local demo workspace</span></div>
          <Settings2 size={16} className="muted"/>
        </div>
      </div>
    </aside>

    <main className="main-area">
      <header className="topbar">
        <div className="breadcrumbs"><span>Workspace</span><span className="crumb-slash">/</span><strong>{navItems.find(n => n.id === page)?.label || 'Overview'}</strong></div>
        <div className="top-actions"><span className="demo-pill"><span/> DEMO MODE</span><button className="icon-button" title="Help" onClick={() => setNotice('Demo mode uses illustrative analysis. Connect a backend for real analysis and generation.')}><CircleHelp size={18}/></button></div>
      </header>

      <div className="content">
        {page === 'home' && <HomePage setPage={setPage} file={file} analysis={analysis} hasGenerated={hasGenerated} instrument={instrument} />}
        {page === 'upload' && <UploadPage file={file} audioUrl={audioUrl} fileSize={fileSize} fileRef={fileRef} loadFile={loadFile} analyze={analyze} isAnalyzing={isAnalyzing} progress={progress} done={done} />}
        {page === 'instrument' && <InstrumentPage instruments={instruments} instrument={instrument} setInstrument={setInstrument} selected={selected} analysis={analysis} file={file} generate={generate} isGenerating={isGenerating} progress={progress} />}
        {page === 'compare' && <ComparePage file={file} audioUrl={audioUrl} generatedUrl={generatedUrl} generatedInstrument={generatedInstrument} instruments={instruments} setPage={setPage} setInstrument={setInstrument} />}
        {page === 'review' && <ReviewPage file={file} analysis={analysis} generatedInstrument={generatedInstrument} instruments={instruments} setInstrument={setInstrument} generate={generate} isGenerating={isGenerating} setPage={setPage} />}
      </div>
      <footer className="footer"><span>✦ Made for the music you imagine.</span><span>Audio stays in this browser session in demo mode.</span></footer>
    </main>
    {notice && <div className="toast"><Info size={17}/><span>{notice}</span><button onClick={() => setNotice('')}><X size={15}/></button></div>}
  </div>;
}

function PageHeading({eyebrow, title, description, right}) {
  return <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line"/>{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{right}</div>;
}
function HomePage({setPage, file, analysis, hasGenerated, instrument}) {
  return <>
    <section className="hero-panel">
      <div className="hero-glow"/><div className="hero-copy">
        <div className="eyebrow"><span className="eyebrow-line"/> YOUR IDEA, REIMAGINED</div>
        <h1>Every melody has<br/>another <em>side.</em></h1>
        <p>Bring your original tune to the studio. Explore new instrument colours, compare ideas, and get thoughtful feedback on your sound.</p>
        <div className="hero-buttons"><button className="primary-button" onClick={() => setPage(file ? 'instrument' : 'upload')}><WandSparkles size={17}/>{file ? 'Continue your session' : 'Start creating'}<ArrowRight size={16}/></button><button className="text-button" onClick={() => setPage('review')}>Explore AI review <ArrowRight size={15}/></button></div>
        <div className="hero-stats"><div><strong>07</strong><span>Instruments to explore</span></div><div><strong>01</strong><span>Original melody</span></div><div><strong>∞</strong><span>Ways to reinterpret</span></div></div>
      </div>
      <div className="hero-art" aria-label="Decorative abstract audio waveform">
        <div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit orbit-three"/>
        <div className="art-disc"><div className="disc-inner"><AudioLines size={50}/><span>TC</span></div></div>
        <div className="float-chip chip-top"><span className="chip-icon"><Waves size={15}/></span><div><strong>Melody first</strong><small>Keep your original idea</small></div></div>
        <div className="float-chip chip-bottom"><span className="sound-bars">{Array.from({length:12},(_,i)=><i key={i} style={{height:`${10+(i*13)%25}px`}}/>)}</span><div><strong>Find your sound</strong><small>Explore a new instrument</small></div></div>
      </div>
      <div className="hero-grain"/>
    </section>

    <div className="section-heading"><div><h2>Your creative workflow</h2><p>From first note to a fresh perspective.</p></div><span className="section-count">01 — 04</span></div>
    <div className="workflow-grid">
      {[
        {n:'01',icon:Upload,title:'Bring your tune',desc:'Upload an MP3 or WAV recording of your original melody.',page:'upload',tag:'START HERE'},
        {n:'02',icon:ScanSearch,title:'Understand the sound',desc:'Review tempo, key, mood and rhythm analysis.',page:'upload',tag:'ANALYZE'},
        {n:'03',icon:Music2,title:'Try a new voice',desc:'Choose an instrument to imagine a different arrangement.',page:'instrument',tag:'EXPERIMENT'},
        {n:'04',icon:Sparkles,title:'Reflect & refine',desc:'Get suitability notes and explore alternative instruments.',page:'review',tag:'GET INSIGHT'}
      ].map((x,i)=>{const Icon=x.icon;return <button className="workflow-card" key={x.n} onClick={()=>setPage(x.page)}><div className="workflow-top"><span className="workflow-icon"><Icon size={19}/></span><span className="workflow-n">{x.n}</span></div><span className="card-tag">{x.tag}</span><h3>{x.title}</h3><p>{x.desc}</p><span className="card-arrow"><ArrowRight size={16}/></span></button>})}
    </div>
    <div className="session-strip"><div className="session-symbol"><Disc3 size={20}/></div><div className="session-copy"><strong>{file ? file.name : 'Your next great idea starts with a tune'}</strong><span>{file ? (analysis ? 'Demo analysis complete · Ready to explore instruments' : 'Audio loaded · Ready for analysis') : 'Your session is ready when you are. Upload a melody to get started.'}</span></div><button className="outline-button" onClick={()=>setPage(file ? (analysis?'instrument':'upload') : 'upload')}>{file ? 'Continue' : 'Open studio'} <ArrowRight size={15}/></button></div>
  </>;
}

function UploadPage({file,audioUrl,fileSize,fileRef,loadFile,analyze,isAnalyzing,progress,done}) {
  const [dragging,setDragging] = useState(false);
  const [playing,setPlaying] = useState(false);
  const audio = useRef(null);
  const bars = useMemo(()=>Array.from({length:90},(_,i)=>14+Math.abs(Math.sin(i*.37)*40)+Math.abs(Math.cos(i*.16)*20)),[]);
  return <>
    <PageHeading eyebrow="STEP 01 · SOURCE AUDIO" title="Start with your sound." description="Upload a recording of your original tune. We'll prepare it for a new instrumental interpretation."/>
    <div className="upload-layout">
      <div className="panel upload-panel">
        <div className="panel-title"><div><h2>Original recording</h2><p>Choose an audio file from your device</p></div><span className="step-badge">01 / 04</span></div>
        {!file ? <div className={`dropzone ${dragging?'dragging':''}`} onDragOver={e=>{e.preventDefault();setDragging(true)}} onDragLeave={()=>setDragging(false)} onDrop={e=>{e.preventDefault();setDragging(false);loadFile(e.dataTransfer.files?.[0])}} onClick={()=>fileRef.current?.click()} role="button" tabIndex="0" onKeyDown={e=>e.key==='Enter'&&fileRef.current?.click()}>
          <input ref={fileRef} type="file" accept=".mp3,.wav,audio/mpeg,audio/wav" hidden onChange={e=>loadFile(e.target.files?.[0])}/>
          <div className="upload-icon"><Upload size={25}/></div><h3>Drop your tune here</h3><p>or <span>browse files</span> on your computer</p><div className="file-types"><span><FileAudio size={14}/> MP3</span><span><FileAudio size={14}/> WAV</span><i/> Max 25 MB</div>
        </div> : <div className="loaded-file"><div className="file-art"><AudioWaveform size={27}/></div><div className="file-meta"><strong>{file.name}</strong><span>{fileSize} · Audio loaded locally</span><div className="waveform compact">{bars.map((h,i)=><i key={i} style={{height:`${h*.55}px`,opacity:.45+(i%5)*.1}}/>)}</div></div><button className="icon-button" onClick={()=>fileRef.current?.click()} title="Choose another file"><RefreshCw size={17}/></button><input ref={fileRef} type="file" accept=".mp3,.wav,audio/mpeg,audio/wav" hidden onChange={e=>loadFile(e.target.files?.[0])}/></div>}
        {file && <div className="audio-player"><audio ref={audio} src={audioUrl} onPlay={()=>setPlaying(true)} onPause={()=>setPlaying(false)} onEnded={()=>setPlaying(false)} controls /></div>}
        <div className="upload-notes"><div><Check size={15}/><span>Your file stays in this browser demo.</span></div><div><Check size={15}/><span>Analysis values below are illustrative until an API is connected.</span></div></div>
        <div className="panel-actions"><span className="privacy-note"><Info size={14}/> No upload to a server</span><button className="primary-button" onClick={analyze} disabled={!file||isAnalyzing}>{isAnalyzing?<><LoaderCircle className="spin" size={16}/> Analyzing…</>:<><ScanSearch size={16}/> Analyze tune <ArrowRight size={15}/></>}</button></div>
        {isAnalyzing&&<ProgressBar progress={progress} label="Preparing illustrative analysis"/>}
      </div>
      <div className="side-column">
        <div className="panel side-panel"><div className="side-heading"><span className="side-icon purple"><Activity size={18}/></span><div><h3>What we'll look at</h3><p>A musical snapshot of your idea</p></div></div><div className="analysis-list">{[['Tempo','Speed & pulse'],['Key','Tonal centre'],['Mood','Emotional character'],['Rhythm','Pattern & groove'],['Melody','Phrase movement']].map(([a,b])=><div className="analysis-row" key={a}><span className="analysis-check">{done?<Check size={13}/>:<span/>}</span><div><strong>{a}</strong><small>{b}</small></div><span className="row-status">{done?'READY':'PENDING'}</span></div>)}</div></div>
        <div className="tip-card"><div className="tip-star"><Sparkles size={16}/></div><strong>A small studio tip</strong><p>Try a clear recording with minimal background noise. A single instrument is a great place to begin.</p></div>
      </div>
    </div>
  </>;
}
function ProgressBar({progress,label}) { return <div className="progress-wrap"><div className="progress-label"><span>{label}</span><strong>{progress}%</strong></div><div className="progress-track"><i style={{width:`${progress}%`}}/></div></div>; }

function InstrumentPage({instruments,instrument,setInstrument,selected,analysis,file,generate,isGenerating,progress}) {
  return <>
    <PageHeading eyebrow="STEP 02 · ARRANGEMENT" title="Give your melody a new voice." description="Choose the instrument you want to explore. Your original tune remains the reference point." right={<span className="soft-status"><span/> {file?'TUNE LOADED':'NO TUNE YET'}</span>}/>
    <div className="instrument-layout">
      <div className="panel instrument-panel"><div className="panel-title"><div><h2>Instrument palette</h2><p>Pick a sound to imagine around your melody</p></div><span className="subtle-count">7 OPTIONS</span></div>
        <div className="instrument-grid">{instruments.map(ins=><button key={ins.id} className={`instrument-card ${instrument===ins.id?'chosen':''}`} onClick={()=>setInstrument(ins.id)} style={{'--instrument-color':ins.color}}><span className="instrument-symbol">{ins.icon}</span><span className="instrument-name">{ins.name}</span><span className="instrument-sub">{ins.sub}</span>{instrument===ins.id&&<span className="selected-check"><Check size={12}/></span>}</button>)}</div>
        <div className="selection-preview"><div className="preview-art" style={{'--instrument-color':selected.color}}><span>{selected.icon}</span><div className="preview-ring"/></div><div className="preview-text"><span className="eyebrow">CURRENT SELECTION</span><h3>{selected.name}</h3><p>{selected.desc}</p><div className="tag-row"><span>Melody-led</span><span>Arrangement concept</span></div></div></div>
        <div className="panel-actions"><span className="privacy-note"><Info size={14}/> No generated audio without a connected service</span><button className="primary-button" onClick={generate} disabled={!file||!analysis||isGenerating}>{isGenerating?<><LoaderCircle className="spin" size={16}/> Preparing review…</>:<>Explore this instrument <ArrowRight size={15}/></>}</button></div>
        {isGenerating&&<ProgressBar progress={progress} label="Preparing demo review"/>}
      </div>
      <div className="side-column"><div className="panel side-panel"><div className="side-heading"><span className="side-icon peach"><AudioLines size={18}/></span><div><h3>Your tune at a glance</h3><p>{analysis?'Illustrative demo analysis':'Analyze a tune to see details'}</p></div></div>{analysis?<div className="snapshot-grid">{[['TEMPO',analysis.tempo],['KEY',analysis.key],['MOOD',analysis.mood],['RHYTHM',analysis.rhythm]].map(([k,v])=><div className="snapshot" key={k}><small>{k}</small><strong>{v}</strong></div>)}</div>:<div className="empty-analysis"><Activity size={20}/><p>Your analysis summary will appear here after you upload and analyze a tune.</p></div>}</div><div className="tip-card"><div className="tip-star"><WandSparkles size={16}/></div><strong>Keep the melody in focus</strong><p>This demo offers instrument suitability feedback. Actual melody-preserving audio generation requires a connected music-generation model.</p></div></div>
    </div>
  </>;
}

function ComparePage({file,audioUrl,generatedUrl,generatedInstrument,instruments,setPage,setInstrument}) {
  const [active,setActive] = useState('original');
  const ins = instruments.find(i=>i.id===generatedInstrument);
  return <>
    <PageHeading eyebrow="STEP 03 · LISTEN & COMPARE" title="Two perspectives. One idea." description="Compare your source recording with the new version when a generation service is connected."/>
    {!file ? <div className="panel empty-state"><div className="empty-state-icon"><FileMusic size={28}/></div><h2>Your comparison starts with a tune</h2><p>Upload a recording and choose an instrument to prepare your comparison workspace.</p><button className="primary-button" onClick={()=>setPage('upload')}>Upload a tune <ArrowRight size={15}/></button></div> : <div className="compare-stack">
      <div className="compare-tabs"><button className={active==='original'?'active':''} onClick={()=>setActive('original')}><span className="tab-dot original-dot"/> Original tune</button><button className={active==='generated'?'active':''} onClick={()=>setActive('generated')}><span className="tab-dot generated-dot"/> Instrument version</button></div>
      <div className="compare-grid">
        <div className={`panel compare-card ${active==='original'?'focused':''}`}><div className="compare-card-head"><div className="track-number">A</div><div><span className="track-label">SOURCE RECORDING</span><h3>Original tune</h3></div><span className="track-pill">ORIGINAL</span></div><div className="big-wave wave-original">{Array.from({length:76},(_,i)=><i key={i} style={{height:`${12+Math.abs(Math.sin(i*.43)*48)+Math.abs(Math.cos(i*.13)*20)}px`}}/>)}</div><div className="track-file"><FileAudio size={16}/><span>{file.name}</span></div>{audioUrl?<audio controls src={audioUrl} className="full-audio"/>:<div className="audio-placeholder">No source audio</div>}<div className="track-footer"><span><Check size={14}/> Source ready</span><span>Local file</span></div></div>
        <div className={`panel compare-card ${active==='generated'?'focused':''}`}><div className="compare-card-head"><div className="track-number track-number-b">B</div><div><span className="track-label">NEW ARRANGEMENT</span><h3>{ins?ins.name:'Instrument version'}</h3></div><span className="track-pill pending-pill">{generatedUrl?'READY':'NOT GENERATED'}</span></div>
          <div className="generated-visual"><div className="generated-orb"><AudioWaveform size={34}/></div><div className="generated-state">{generatedUrl?<><strong>Generated audio ready</strong><span>Play the new arrangement below.</span></>:<><strong>Waiting for a music-generation API</strong><span>This workspace will play a real result when your backend returns an audio URL.</span></>}</div></div>
          {generatedUrl?<audio controls src={generatedUrl} className="full-audio"/>:<div className="not-generated"><Info size={15}/> No audio has been generated in demo mode.</div>}<div className="track-footer"><span>{generatedUrl?<><Check size={14}/> Generated by connected service</>:'Demo review only'}</span><span>{ins?ins.name:'Choose instrument'}</span></div></div>
      </div>
      <div className="compare-note"><div className="note-icon"><Info size={17}/></div><p><strong>Honest by design.</strong> The visual waveform is illustrative. TuneCraft does not fabricate a generated track or claim the original melody has been preserved without a real generation service.</p><button className="text-button" onClick={()=>setPage('review')}>View review <ArrowRight size={15}/></button></div>
      <div className="center-actions"><button className="outline-button" onClick={()=>setPage('instrument')}><ArrowLeft size={15}/> Change instrument</button><button className="primary-button" onClick={()=>setPage('review')}>Continue to AI review <ArrowRight size={15}/></button></div>
    </div>}
  </>;
}

function ReviewPage({file,analysis,generatedInstrument,instruments,setInstrument,generate,isGenerating,setPage}) {
  const ins = instruments.find(i=>i.id===generatedInstrument);
  const [showAlternatives,setShowAlternatives] = useState(true);
  const alternatives = instruments.filter(i=>i.id!==(generatedInstrument||'piano')).slice(0,3);
  return <>
    <PageHeading eyebrow="STEP 04 · CREATIVE FEEDBACK" title="A second opinion for your sound." description="A transparent, step-by-step suitability review to help you decide what to try next."/>
    {!file ? <div className="panel empty-state"><div className="empty-state-icon"><Sparkles size={28}/></div><h2>Your musical review is waiting</h2><p>Upload a tune and select an instrument to create a clearly labelled demo review.</p><button className="primary-button" onClick={()=>setPage('upload')}>Start with a tune <ArrowRight size={15}/></button></div> : <>
      <div className="review-banner"><div className="review-banner-icon"><Sparkles size={22}/></div><div><span className="eyebrow">TUNECRAFT CREATIVE NOTES</span><h2>{ins?`${ins.name} · suitability review`:'Your instrument review'}</h2><p>{analysis?'Illustrative guidance based on the selected instrument and demo analysis.':'Upload analysis is not ready yet; feedback is general and illustrative.'}</p></div><span className="demo-label">DEMO REVIEW</span></div>
      <div className="review-layout"><div className="panel review-steps"><div className="panel-title"><div><h2>How the instrument fits</h2><p>A structured creative assessment</p></div><span className="subtle-count">4 STEPS</span></div>
        {[
          {n:'01',title:'Melody compatibility',tag:'CONCEPT',body:ins?`${ins.name} can offer a distinct lead colour for a melody-led arrangement. A real analysis of note range and phrasing is needed to confirm the fit.`:'Choose an instrument to see a tailored suitability note.'},
          {n:'02',title:'Tone & emotional colour',tag:'LISTEN FOR',body:ins?ins.desc+' Listen for whether this tone supports the feeling you want the piece to communicate.': 'Think about whether you want a warm, bright, airy, or percussive tone.'},
          {n:'03',title:'Rhythm & arrangement',tag:'ARRANGEMENT',body:'Consider how the instrument’s attack, sustain, and rhythmic role interact with your original pulse. The right arrangement should leave the central melodic idea recognizable.'},
          {n:'04',title:'What to validate next',tag:'NEXT STEP',body:'Compare the generated audio against your source melody, then check timing, note accuracy, and phrasing. These checks need real audio output and analysis; they are not verified in this demo.'}
        ].map((s,i)=><div className="review-step" key={s.n}><div className="step-rail"><span>{s.n}</span>{i<3&&<i/>}</div><div className="step-body"><div className="step-body-top"><h3>{s.title}</h3><span>{s.tag}</span></div><p>{s.body}</p></div></div>)}
        <div className="review-disclaimer"><Info size={15}/><span>This is illustrative guidance, not an AI model evaluation of the uploaded waveform.</span></div>
      </div>
      <div className="side-column"><div className="panel alternative-panel"><button className="alternative-head" onClick={()=>setShowAlternatives(!showAlternatives)}><div><span className="side-icon purple"><WandSparkles size={17}/></span><div><h3>Try another colour</h3><p>Alternative instrument ideas</p></div></div><ChevronDown size={17} className={showAlternatives?'':'rotated'}/></button>
        {showAlternatives&&<div className="alternative-list">{alternatives.map((a,i)=><div className="alternative" key={a.id}><div className="alternative-symbol" style={{'--instrument-color':a.color}}>{a.icon}</div><div className="alternative-info"><strong>{a.name}</strong><p>{a.desc}</p></div><button className="small-select" onClick={()=>{setInstrument(a.id);setPage('instrument')}}>Try <ArrowRight size={13}/></button></div>)}</div>}
      </div><div className="next-card"><span className="next-card-icon"><RefreshCw size={18}/></span><h3>Curiosity is part of the process.</h3><p>Switch instruments and compare the ideas. No generated audio will be claimed until a real service returns it.</p><button className="primary-button full-button" onClick={()=>setPage('instrument')}>Regenerate with another instrument <ArrowRight size={15}/></button></div></div></div>
    </>}
  </>;
}

createRoot(document.getElementById('root')).render(<App/>);
