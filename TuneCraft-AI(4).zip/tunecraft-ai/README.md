# TuneCraft AI — Music Co-Pilot

A responsive React + Vite frontend for a music co-pilot workflow. This is a **demo frontend**, not a real audio-generation system.

## Run locally

1. Install Node.js (Node 18+ recommended).
2. Extract this ZIP and open the `tunecraft-ai` folder in VS Code.
3. Open Terminal in that folder and run:

```bash
npm install
npm run dev
```

4. Open the local URL Vite prints (usually `http://localhost:5173`).

To test a production build:

```bash
npm run build
npm run preview
```

## What's functional

- Responsive multi-page navigation: Overview, Upload & Analyze, Instrument Lab, Compare Versions, AI Review.
- Local MP3/WAV file selection and drag-and-drop, 25 MB limit, in-browser audio playback.
- Simulated progress states and clearly labelled **illustrative demo analysis**.
- Seven selectable instruments, suitability review, alternative suggestions, and switching instruments.
- Compare workspace that honestly shows no generated audio until a backend provides a real output URL.
- Error / status toasts and loading states.

## Important demo limitation

The analysis metrics are illustrative and are **not computed from the uploaded audio**. The app does not generate a replacement track. No API is connected, and the comparison page intentionally refuses to pretend that a generated recording exists.

## Backend integration plan

Keep API keys on the server. Suggested endpoints:

- `POST /api/analyze` — multipart audio upload; returns `{ "tempoBpm": 96, "key": "A minor", "mood": "reflective", "rhythm": "4/4", "melodySummary": "...", "confidence": 0.82 }`.
- `POST /api/generate` — multipart audio plus `{ "instrument": "piano", "preserveMelody": true }`; returns `{ "jobId": "...", "status": "queued" }`.
- `GET /api/generate/:jobId` — returns `{ "status": "processing" }` until ready, then `{ "status": "completed", "audioUrl": "https://...", "preserveMelodyScore": 0.91 }`.
- `POST /api/review` — returns evidence-grounded suitability, limitations, and alternatives for the selected instrument.

For generation, only show a playable generated version after the backend returns a real `audioUrl`. Validate file type/size on both client and server, limit request duration, clean up temporary files, and use authenticated, expiring URLs for audio output.

## Structure

```text
tunecraft-ai/
├── index.html
├── package.json
├── README.md
└── src/
    ├── main.jsx
    └── styles.css
```
